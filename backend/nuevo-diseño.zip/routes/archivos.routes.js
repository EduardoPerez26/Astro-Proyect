// File routes.
const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { pool } = require('../config/database');
const { verificarToken, checkPermission } = require('../middleware/auth.middleware');

const storage = multer.memoryStorage();
const upload = multer({
    storage,
    limits: { fileSize: Number(process.env.MAX_FILE_SIZE_MB || 50) * 1024 * 1024 }
});

function debeFiltrarPorDepartment(req) {
    return req.usuario?.rol !== 'superadmin' && Boolean(req.departamento?.id);
}

async function obtenerArchivoPorId(req, archivoId) {
    if (!debeFiltrarPorDepartment(req)) {
        const [archivos] = await pool.query(
            'SELECT * FROM archivos_excel WHERE id = ?',
            [archivoId]
        );
        return archivos;
    }

    try {
        const [archivos] = await pool.query(
            `SELECT *
             FROM archivos_excel
             WHERE id = ?
               AND (departamento_id = ? OR departamento_id IS NULL)`,
            [archivoId, req.departamento.id]
        );
        return archivos;
    } catch (error) {
        if (error.code !== 'ER_BAD_FIELD_ERROR') throw error;

        const [archivos] = await pool.query(
            'SELECT * FROM archivos_excel WHERE id = ?',
            [archivoId]
        );
        return archivos;
    }
}

router.get(
    '/',
    verificarToken,
    checkPermission('view_archivos'),
    async (req, res) => {
        try {

            let rows;
            const whereDepartment = debeFiltrarPorDepartment(req)
                ? 'WHERE (a.departamento_id = ? OR a.departamento_id IS NULL)'
                : '';
            const paramsDepartment = debeFiltrarPorDepartment(req)
                ? [req.departamento.id]
                : [];

            try {
                [rows] = await pool.query(`
                    SELECT
                        a.id,
                        a.usuario_id,
                        a.departamento_id,
                        a.restaurante_id,
                        a.nombre_original,
                        a.nombre_servidor,
                        a.tamano_bytes,
                        a.tipo_mime,
                        a.ruta_archivo,
                        a.numero_hojas,
                        a.nombres_hojas,
                        a.estado,
                        a.periodo_fecha,
                        a.notas,
                        a.fecha_subida,
                        a.fecha_actualizacion,
                        (a.archivo_blob IS NOT NULL AND OCTET_LENGTH(a.archivo_blob) > 0) AS tiene_blob,
                        r.nombre AS restaurante_nombre,
                        r.codigo AS restaurante_codigo,
                        u.username,
                        u.nombre_completo AS usuario_nombre
                    FROM archivos_excel a
                    LEFT JOIN restaurantes r
                        ON r.id = a.restaurante_id
                    LEFT JOIN usuarios u
                        ON u.id = a.usuario_id
                    ${whereDepartment}
                    ORDER BY a.id DESC
                `, paramsDepartment);
            } catch (error) {
                if (error.code !== 'ER_BAD_FIELD_ERROR') throw error;

                [rows] = await pool.query(`
                    SELECT
                        a.id,
                        a.usuario_id,
                        NULL AS departamento_id,
                        a.restaurante_id,
                        a.nombre_original,
                        a.nombre_servidor,
                        a.tamano_bytes,
                        a.tipo_mime,
                        a.ruta_archivo,
                        a.numero_hojas,
                        a.nombres_hojas,
                        a.estado,
                        a.periodo_fecha,
                        a.notas,
                        a.fecha_subida,
                        a.fecha_actualizacion,
                        (a.archivo_blob IS NOT NULL AND OCTET_LENGTH(a.archivo_blob) > 0) AS tiene_blob,
                        r.nombre AS restaurante_nombre,
                        r.codigo AS restaurante_codigo,
                        u.username,
                        u.nombre_completo AS usuario_nombre
                    FROM archivos_excel a
                    LEFT JOIN restaurantes r
                        ON r.id = a.restaurante_id
                    LEFT JOIN usuarios u
                        ON u.id = a.usuario_id
                    ORDER BY a.id DESC
                `);
            }

            const archivos = rows.map(row => ({
                ...row,
                archivoExiste: (
                    Boolean(row.tiene_blob) ||
                    Boolean(
                        row.ruta_archivo &&
                        fs.existsSync(row.ruta_archivo)
                    )
                )
            }));

            res.json(archivos);

        } catch (error) {

            console.error('Files could not be loaded:', error);

            res.status(500).json({
                error: true,
                message: 'Files could not be loaded'
            });
        }
    }
);

router.post(
    '/subir',
    verificarToken,
    checkPermission('upload_files'),
    upload.single('archivo'),
    async (req, res) => {
        try {

            if (!req.file) {
                return res.status(400).json({
                    error: true,
                    message: 'No file was received'
                });
            }

            const restauranteCodigo = req.body.restaurante_id;

            const [restaurantes] = await pool.query(
                'SELECT id FROM restaurantes WHERE codigo = ? LIMIT 1',
                [restauranteCodigo]
            );

            if (!restaurantes.length) {
                return res.status(400).json({
                    error: true,
                    message: 'Restaurant not found'
                });
            }

            const restauranteId = restaurantes[0].id;

            const {
                originalname,
                size,
                mimetype,
                buffer
            } = req.file;
            const nombreServidor = `${Date.now()}-${originalname}`;
            const esReferenciaComparacion =
                String(req.body.es_referencia_comparacion || '').toLowerCase() === 'true';
            const esReviewFuente =
                String(req.body.es_revision_fuente || '').toLowerCase() === 'true';
            let resumenContenido = null;

            if (esReferenciaComparacion && req.body.resumen_contenido) {
                try {
                    resumenContenido = JSON.parse(req.body.resumen_contenido);
                } catch {
                    resumenContenido = null;
                }
            }

            const notas = esReferenciaComparacion
                ? JSON.stringify({
                    tipo: 'referencia_comparacion',
                    fuente: req.body.tipo_fuente || 'sales',
                    hash: String(req.body.hash_contenido || '').slice(0, 64),
                    nombreOriginal: originalname,
                    resumen: resumenContenido
                })
                : esReviewFuente
                    ? JSON.stringify({
                        tipo: 'revision_fuente',
                        fuente: req.body.tipo_fuente || 'sales',
                        revision: Number(req.body.revision || 1),
                        hash: String(req.body.hash_contenido || '').slice(0, 64),
                        nombreOriginal: originalname
                    })
                    : (req.body.notas || null);

            if (esReferenciaComparacion) {
                const fuente = req.body.tipo_fuente || 'sales';
                const [candidatos] = await pool.query(
                    `SELECT id, notas
                     FROM archivos_excel
                     WHERE restaurante_id = ?
                     ORDER BY id DESC`,
                    [restauranteId]
                );
                const referenciaAnterior = candidatos.find(candidato => {
                    try {
                        const meta = JSON.parse(candidato.notas || '{}');
                        return (
                            ['referencia_comparacion', 'revision_fuente'].includes(meta.tipo) &&
                            meta.fuente === fuente
                        );
                    } catch {
                        return false;
                    }
                });

                if (referenciaAnterior) {
                    const nombresHojas = resumenContenido?.hojas
                        ?.map(hoja => hoja.nombre)
                        .join(', ') || null;

                    await pool.query(
                        `UPDATE archivos_excel
                         SET nombre_original = ?,
                             nombre_servidor = ?,
                             tamano_bytes = ?,
                             tipo_mime = ?,
                             archivo_blob = ?,
                             ruta_archivo = NULL,
                             numero_hojas = ?,
                             nombres_hojas = ?,
                             notas = ?,
                             estado = 'pendiente',
                             fecha_actualizacion = CURRENT_TIMESTAMP
                         WHERE id = ?`,
                        [
                            originalname,
                            nombreServidor,
                            size,
                            mimetype,
                            buffer,
                            resumenContenido?.totalHojas || null,
                            nombresHojas,
                            notas,
                            referenciaAnterior.id
                        ]
                    );

                    return res.json({
                        success: true,
                        reemplazado: true,
                        archivo: { id: referenciaAnterior.id }
                    });
                }
            }

            function normalizarFechaArchivo(valor) {
                if (!valor) return '';

                if (valor instanceof Date && !Number.isNaN(valor.getTime())) {
                    return valor.toISOString().slice(0, 10);
                }

                const texto = String(valor).trim();

                // Ya viene como YYYY-MM-DD
                if (/^\d{4}-\d{2}-\d{2}/.test(texto)) {
                    return texto.slice(0, 10);
                }

                // Viene como MM/DD/YYYY
                const matchUsa = texto.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
                if (matchUsa) {
                    return `${matchUsa[3]}-${matchUsa[1].padStart(2, '0')}-${matchUsa[2].padStart(2, '0')}`;
                }

                const fecha = new Date(texto);

                if (!Number.isNaN(fecha.getTime())) {
                    return fecha.toISOString().slice(0, 10);
                }

                return texto;
            }

            const reemplazarSiExiste =
                String(req.body.reemplazar_si_existe || '').toLowerCase() === 'true';

            const archivoReemplazarId =
                Number(req.body.archivo_reemplazar_id || 0);

            const confirmacionReemplazo =
                String(req.body.confirmacion_reemplazo || '')
                    .trim()
                    .toUpperCase();

            const limpiarCampo = value => {
                const texto = String(value || '').trim();

                if (
                    !texto ||
                    texto === 'undefined' ||
                    texto === 'null'
                ) {
                    return '';
                }

                return texto;
            };

            const tipoDocumento =
                limpiarCampo(req.body.tipo_documento);

            const fechaDocumento =
                limpiarCampo(
                    req.body.fecha_conciliacion ||
                    req.body.periodo_fecha
                );

            const esArchivoGeneradoConciliacion =
                /_(Conciliacion|EBT)\./i.test(String(originalname || ''));

            const fechaDocumentoNormalizada =
                normalizarFechaArchivo(fechaDocumento);

            const parsearNotasArchivo = valor => {
                try {
                    return typeof valor === 'string'
                        ? JSON.parse(valor)
                        : valor || {};
                } catch {
                    return {};
                }
            };

            const actualizarArchivoExistente = async id => {
                await pool.query(
                    `
                    UPDATE archivos_excel
                    SET nombre_original = ?,
                        nombre_servidor = ?,
                        tamano_bytes = ?,
                        tipo_mime = ?,
                        archivo_blob = ?,
                        ruta_archivo = NULL,
                        periodo_fecha = ?,
                        notas = ?,
                        estado = 'pendiente',
                        fecha_actualizacion = CURRENT_TIMESTAMP
                    WHERE id = ?
                    `,
                    [
                        originalname,
                        nombreServidor,
                        size,
                        mimetype,
                        buffer,
                        fechaDocumentoNormalizada || null,
                        notas,
                        id
                    ]
                );

                return res.json({
                    success: true,
                    reemplazado: true,
                    archivo: {
                        id
                    }
                });
            };

            if (archivoReemplazarId) {
                if (
                    !reemplazarSiExiste ||
                    confirmacionReemplazo !== 'REEMPLAZAR'
                ) {
                    return res.status(400).json({
                        error: true,
                        code: 'CONFIRMACION_REEMPLAZO_REQUERIDA',
                        message: 'The replacement confirmation is not valid.'
                    });
                }

                const [archivoConfirmado] = await pool.query(
                    `SELECT id
                     FROM archivos_excel
                     WHERE id = ?
                       AND restaurante_id = ?
                     LIMIT 1`,
                    [archivoReemplazarId, restauranteId]
                );

                if (!archivoConfirmado.length) {
                    return res.status(409).json({
                        error: true,
                        code: 'ARCHIVO_REEMPLAZO_NO_DISPONIBLE',
                        message: 'The file you confirmed for replacement is no longer available. Refresh the page and try again.'
                    });
                }

                return await actualizarArchivoExistente(archivoReemplazarId);
            }

            const validarDuplicadosGenerados =
                Boolean(
                    tipoDocumento ||
                    fechaDocumentoNormalizada ||
                    esArchivoGeneradoConciliacion ||
                    reemplazarSiExiste
                );

            if (validarDuplicadosGenerados) {
                const [candidatos] = await pool.query(
                    `SELECT id, nombre_original, periodo_fecha, notas
                     FROM archivos_excel
                     WHERE restaurante_id = ?
                     ORDER BY id DESC
                     LIMIT 500`,
                    [restauranteId]
                );

                const duplicado = candidatos.find(candidato => {
                    const nombreActual = String(candidato.nombre_original || '');
                    const mismoNombre =
                        nombreActual.trim().toLowerCase() ===
                        String(originalname || '').trim().toLowerCase();

                    const meta = parsearNotasArchivo(candidato.notas);
                    const fechaCandidato = normalizarFechaArchivo(
                        meta.fecha ||
                        meta.fecha_conciliacion ||
                        candidato.periodo_fecha
                    );

                    const mismoTipo =
                        tipoDocumento &&
                        (
                            meta.tipoDocumento === tipoDocumento ||
                            (
                                tipoDocumento === 'conciliacion' &&
                                /_Conciliacion\./i.test(nombreActual)
                            ) ||
                            (
                                tipoDocumento === 'ebt' &&
                                /_EBT\./i.test(nombreActual)
                            )
                        );

                    const mismaFecha =
                        fechaDocumentoNormalizada &&
                        (
                            fechaCandidato === fechaDocumentoNormalizada ||
                            nombreActual.includes(fechaDocumentoNormalizada)
                        );

                    return mismoNombre || (mismoTipo && mismaFecha);
                });

                if (duplicado) {
                    return res.status(409).json({
                        error: true,
                        code: 'ARCHIVO_DUPLICADO',
                        message: 'A file already exists for this restaurant and document. Confirm the replacement before uploading.',
                        archivo: {
                            id: duplicado.id,
                            nombre_original: duplicado.nombre_original
                        }
                    });
                }
            }


            let result;
            const paramsArchivo = [
                req.usuario.id,
                req.departamento?.id || null,
                restauranteId,
                originalname,
                nombreServidor,
                size,
                mimetype,
                buffer,
                null,
                fechaDocumentoNormalizada || null,
                notas,
                'pendiente'
            ];

            try {
                [result] = await pool.query(
                    `
                    INSERT INTO archivos_excel (
                    usuario_id,
                    departamento_id,
                    restaurante_id,
                    nombre_original,
                    nombre_servidor,
                    tamano_bytes,
                    tipo_mime,
                    archivo_blob,
                    ruta_archivo,
                    periodo_fecha,
                    notas,
                    estado
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    `,
                    paramsArchivo
                );
            } catch (error) {
                if (error.code !== 'ER_BAD_FIELD_ERROR') throw error;

                [result] = await pool.query(
                    `
                    INSERT INTO archivos_excel (
                    usuario_id,
                    restaurante_id,
                    nombre_original,
                    nombre_servidor,
                    tamano_bytes,
                    tipo_mime,
                    archivo_blob,
                    ruta_archivo,
                    periodo_fecha,
                    notas,
                    estado
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    `,
                    [
                        req.usuario.id,
                        restauranteId,
                        originalname,
                        nombreServidor,
                        size,
                        mimetype,
                        buffer,
                        null,
                        fechaDocumentoNormalizada || null,
                        notas,
                        'pendiente'
                    ]
                );
            }

            res.json({
                success: true,
                archivo: {
                    id: result.insertId
                }
            });

        } catch (error) {

            console.error('Error uploading file:', error);

            res.status(500).json({
                error: true,
                message: error.message
            });
        }
    }
);

router.get(
    '/:id/descargar',
    verificarToken,
    checkPermission('download_files'),
    async (req, res) => {
        try {

            const archivos = await obtenerArchivoPorId(req, req.params.id);

            if (!archivos.length) {
                return res.status(404).json({
                    error: true,
                    message: 'File not found'
                });
            }

            const archivo = archivos[0];

            if (archivo.archivo_blob) {
                const contenido = Buffer.isBuffer(archivo.archivo_blob)
                    ? archivo.archivo_blob
                    : Buffer.from(archivo.archivo_blob);

                res.setHeader(
                    'Content-Type',
                    archivo.tipo_mime || 'application/octet-stream'
                );
                res.setHeader('Content-Length', contenido.length);
                res.setHeader(
                    'Content-Disposition',
                    `attachment; filename*=UTF-8''${encodeURIComponent(archivo.nombre_original)}`
                );
                return res.send(contenido);
            }

            if (
                archivo.ruta_archivo &&
                fs.existsSync(archivo.ruta_archivo)
            ) {
                return res.download(
                    archivo.ruta_archivo,
                    archivo.nombre_original
                );
            }

            return res.status(410).json({
                error: true,
                message: 'The previous file no longer exists in temporary storage. It must be uploaded again.'
            });

        } catch (error) {

            console.error('Error downloading file:', error);

            res.status(500).json({
                error: true,
                message: 'Error downloading file'
            });
        }
    }
);

router.delete(
    '/:id',
    verificarToken,
    checkPermission('delete_files'),
    async (req, res) => {
        try {

            const archivos = await obtenerArchivoPorId(req, req.params.id);

            if (!archivos.length) {
                return res.status(404).json({
                    error: true,
                    message: 'File not found'
                });
            }

            const archivo = archivos[0];

            if (
                archivo.ruta_archivo &&
                fs.existsSync(archivo.ruta_archivo)
            ) {
                fs.unlinkSync(archivo.ruta_archivo);
            }

            await pool.query(
                'DELETE FROM archivos_excel WHERE id = ?',
                [req.params.id]
            );

            res.json({
                success: true,
                message: 'File deleted successfully'
            });

        } catch (error) {

            console.error(
                'Error deleting file:',
                error
            );

            res.status(500).json({
                error: true,
                message: 'Error deleting file'
            });
        }
    }
);

module.exports = router;
